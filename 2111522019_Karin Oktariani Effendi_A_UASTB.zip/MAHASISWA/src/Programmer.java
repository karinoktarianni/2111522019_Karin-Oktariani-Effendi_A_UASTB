// Class
public class Programmer {
    String namaProgrammer;
    int nimProgrammer;
    String tugas;

    // Constructor
    public Programmer() {
        namaProgrammer = "Karin Oktariani Effendi";
        nimProgrammer = 2111522019;
        tugas = "UAS PBO KELAS A (01)";
    }
}
